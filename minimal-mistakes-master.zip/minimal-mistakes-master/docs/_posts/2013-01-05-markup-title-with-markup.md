---
title: "Markup: Title *with* **Markdown**"
categories:
  - Markdown
tags:
  - css
  - html
  - title
---

Verify that:

* The post title renders the word "with" in *italics* and the word "Markdown" in **bold**.
* The post title markup should be removed from the browser window / tab.